var r =100;

function setup() {
  createCanvas(500, 500);
  background(255);
}
function draw() {
  rect(mouseX, mouseY, r, r);
}